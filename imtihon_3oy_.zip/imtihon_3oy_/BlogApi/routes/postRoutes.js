const express = require('express');
const router = express.Router();
const db = require('../utils/db'); 
router.post('/', async (req, res) => {
  try {
    const { title, content, authorId, tags, categoryId, status } = req.body;
    const [postId] = await db('posts').insert({
      title,
      content,
      authorId,
      tags: JSON.stringify(tags),
      categoryId,
      status
    }).returning('id');
    res.json({ postId, message: 'Post created' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
router.get('/', async (req, res) => {
  try {
    const posts = await db('posts').select('*');
    res.json(posts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
