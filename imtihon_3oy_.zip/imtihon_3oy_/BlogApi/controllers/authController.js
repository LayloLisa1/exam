const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const otpGenerator = require('otp-generator');
const { sendOtp } = require('../utils/sendOtp');
const authController = {
  async signup(req, res) {
    const { email, username, password, role } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = {
        email,
        username,
        password: hashedPassword,
        role,
        status: 'inactive',
        otp: otpGenerator.generate(6, { digits: true, alphabets: false, upperCase: false, specialChars: false })
      };
      const newUser = await User.create(user);
      await sendOtp(email, user.otp);
      res.status(201).json({ message: 'User created', userId: newUser[0].id, otpSent: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
  async verify(req, res) {
    const { email, otp } = req.body;
    try {
      const user = await User.findByEmail(email);
      if (user.otp === otp) {
        await User.updateStatus(email, 'active'); 
        res.json({ message: 'User verified' });
      } else {
        res.status(400).json({ error: 'Invalid OTP' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
  async signin(req, res) {
    const { email, password } = req.body;
    try {
      const user = await User.findByEmail(email);
      if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }
      const accessToken = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRATION });
      const refreshToken = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.REFRESH_TOKEN_EXPIRATION });
      res.json({ accessToken, refreshToken });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
  async refresh(req, res) {
    const { token } = req.body;
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const newAccessToken = jwt.sign({ id: decoded.id, role: decoded.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRATION });
      res.json({ accessToken: newAccessToken });
    } catch (error) {
      res.status(401).json({ error: 'Invalid or expired token' });
    }
  },
  async getMe(req, res) {
    try {
      const user = await User.findById(req.user.id);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
  async logout(req, res) {
    res.json({ message: 'Logged out' });
  }
};

module.exports = authController;
