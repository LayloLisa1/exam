const db = require('../utils/db');

const Tag = {
  create: async (tag) => {
    try {
      const result = await db('tags').insert(tag).returning('*');
      return result[0];
    } catch (error) {
      throw new Error(`Error creating tag: ${error.message}`);
    }
  },

  findById: async (id) => {
    try {
      const tag = await db('tags').where({ id }).first();
      return tag;
    } catch (error) {
      throw new Error(`Error finding tag by id: ${error.message}`);
    }
  },

  findAll: async () => {
    try {
      const tags = await db('tags').select('*');
      return tags;
    } catch (error) {
      throw new Error(`Error fetching all tags: ${error.message}`);
    }
  },

  updateById: async (id, data) => {
    try {
      const result = await db('tags').where({ id }).update(data).returning('*');
      return result[0];
    } catch (error) {
      throw new Error(`Error updating tag: ${error.message}`);
    }
  },

  deleteById: async (id) => {
    try {
      await db('tags').where({ id }).del();
    } catch (error) {
      throw new Error(`Error deleting tag by id: ${error.message}`);
    }
  },
};

module.exports = Tag;
