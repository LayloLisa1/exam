const db = require('../utils/db');

const Category = {
  create: async (category) => {
    try {
      const result = await db('categories').insert(category).returning('*');
      return result[0];
    } catch (error) {
      throw new Error(`Error creating category: ${error.message}`);
    }
  },

  findById: async (id) => {
    try {
      const category = await db('categories').where({ id }).first();
      return category;
    } catch (error) {
      throw new Error(`Error finding category by id: ${error.message}`);
    }
  },

  findAll: async () => {
    try {
      const categories = await db('categories').select('*');
      return categories;
    } catch (error) {
      throw new Error(`Error fetching all categories: ${error.message}`);
    }
  },

  updateById: async (id, data) => {
    try {
      const result = await db('categories').where({ id }).update(data).returning('*');
      return result[0];
    } catch (error) {
      throw new Error(`Error updating category: ${error.message}`);
    }
  },

  deleteById: async (id) => {
    try {
      await db('categories').where({ id }).del();
    } catch (error) {
      throw new Error(`Error deleting category by id: ${error.message}`);
    }
  },
};

module.exports = Category;
